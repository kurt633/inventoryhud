var invLocale = new Object();
invLocale.dropItem = "Jeter";
invLocale.useItem = "Utiliser";
invLocale.giveItem = "Donner";
invLocale.secondInventoryNotAvailable = "Le deuxième inventaire n'est pas disponible";
